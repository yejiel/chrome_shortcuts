# Omnibox Alias

Originally cloned from:

    git clone https://github.com/sean-smith/chrome_shortcuts

FEATURES:

---

REMOVE Alias feature.
Import and Export feature.
Neater Design and Layout

Bugfixes:

---

Text overflows

Please continue to contribue to this wonderful extension!
